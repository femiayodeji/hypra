<div style="text-align: center;">
	<h1 style="color:red;">Error</h1>
	<p style="color:green;"> Page not found</p>
</div>
