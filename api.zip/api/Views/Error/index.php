<div style="text-align: center;">
	<h1 style="color:red;">Error Page</h1>
	<p style="color:green;"> Something went wrong!</p>
</div>
