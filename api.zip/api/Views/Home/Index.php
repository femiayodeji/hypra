<?php include("Views/Shared/style.php"); ?>

<div class="banner">
	<h1 class="red"> Hypra</h1>
	<p class="green"> &raquo; A micro framework for building api with PHP</p>
	<a href="/hypra/api/home/doc">Get Started</a> | 	<a href="https://github.com/feminstincts/hypra/" target="_blank">GitHub</a>
</div>

<?php include("Views/Shared/footer.php"); ?>
