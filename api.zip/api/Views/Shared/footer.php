<div class="footer">
	<p style="text-align: center;">
		&copy; Hypra <script type="text/javascript">document.write(new Date().getFullYear());</script>
		a <a href="https://github.com/feminstincts/hypra/" target="_blank">feminstincts</a> Initiative
	</p>
</div>
