<style type="text/css">
	a{
		text-decoration: none;
		color: #000000;
	}
	a:hover,a:active,a:focus{
		color: blue;
	}
	.banner{
		text-align: center;
	}
	.footer{
		background: #cccccc;
		padding: 10px;
/*		position: absolute; 
		bottom: 10px;
		width: 98%; 
*/	}
	.red{
		color: red;
	}
	.green{
		color:green;
	}
</style>