<div style="text-align: center;">
	<h1 style="color:red;">Welcome</h1>
	<p> >>Hypra</p>
</div>
